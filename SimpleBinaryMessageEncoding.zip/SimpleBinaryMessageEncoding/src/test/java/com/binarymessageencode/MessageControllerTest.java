package com.binarymessageencode;
import com.binarymessageencode.Controller.MessageController;
import com.binarymessageencode.Service.Message;
import com.binarymessageencode.Service.MessageCodec;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class MessageControllerTest {

    private MockMvc mockMvc;

    @Mock
    private MessageCodec messageCodec;

    private MessageController messageController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        messageController = new MessageController(messageCodec);
        mockMvc = MockMvcBuilders.standaloneSetup(messageController).build();
    }

    @Test
    public void testEncodeMessage() throws Exception {
        // Mock the behavior of messageCodec.encode
        when(messageCodec.encode(any(Message.class))).thenReturn(new byte[]{1, 2, 3});

        // Create a sample message with headers using a Map
        Message sampleMessage = new Message();
        Map<String, String> headers = new HashMap<>();
        headers.put("key", "value");
        sampleMessage.setHeaders(headers);
        sampleMessage.setPayload(new byte[]{4, 5, 6});

        // Perform a POST request to /api/message/encode with the sample message as JSON
        mockMvc.perform(MockMvcRequestBuilders.post("/api/message/encode")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"headers\": {\"key\": \"value\"}, \"payload\": \"AQID\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().bytes(new byte[]{1, 2, 3}));
    }

    @Test
    public void testDecodeMessage() throws Exception {
        // Mock the behavior of messageCodec.decode
        when(messageCodec.decode(any(byte[].class))).thenReturn(new Message());

        // Perform a POST request to /api/message/decode with a sample byte array as JSON
        mockMvc.perform(MockMvcRequestBuilders.post("/api/message/decode")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("[1, 2, 3]")) // Replace with your sample byte array JSON
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
