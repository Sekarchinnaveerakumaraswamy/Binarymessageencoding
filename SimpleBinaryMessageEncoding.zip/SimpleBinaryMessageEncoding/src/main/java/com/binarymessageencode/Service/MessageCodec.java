package com.binarymessageencode.Service;

public interface MessageCodec {
    byte[] encode(Message message);
    Message decode(byte[] data);
}