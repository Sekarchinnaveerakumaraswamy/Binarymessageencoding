package com.binarymessageencode.Service;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MessageCode implements MessageCodec {

    private static final int MAX_HEADERS = 63;
    private static final int MAX_HEADER_LENGTH = 1023;
    private static final int MAX_PAYLOAD_LENGTH = 256 * 1024; // 256 KiB

    @Override
    public byte[] encode(Message message) {
        // Check for input validity
        if (message.headers == null || message.headers.size() > MAX_HEADERS) {
            throw new IllegalArgumentException("Invalid headers");
        }
        if (message.payload == null || message.payload.length > MAX_PAYLOAD_LENGTH) {
            throw new IllegalArgumentException("Invalid payload");
        }

        // Calculate the total length of the encoded message
        int totalLength = calculateTotalLength(message);

        // Create a ByteBuffer for the encoded message
        ByteBuffer buffer = ByteBuffer.allocate(totalLength);

        // Encode header count
        buffer.put((byte) message.headers.size());

        // Encode headers
        for (Map.Entry<String, String> entry : message.headers.entrySet()) {
            encodeString(buffer, entry.getKey());
            encodeString(buffer, entry.getValue());
        }

        // Encode payload length
        buffer.putInt(message.payload.length);

        // Encode payload
        buffer.put(message.payload);

        return buffer.array();
    }

    @Override
    public Message decode(byte[] data) {
        // Create a ByteBuffer for decoding
        ByteBuffer buffer = ByteBuffer.wrap(data);

        // Decode header count
        int headerCount = buffer.get() & 0xFF;

        // Decode headers
        Map<String, String> headers = new HashMap<>();
        for (int i = 0; i < headerCount; i++) {
            String name = decodeString(buffer);
            String value = decodeString(buffer);
            headers.put(name, value);
        }

        // Decode payload length
        int payloadLength = buffer.getInt();

        // Decode payload
        byte[] payload = new byte[payloadLength];
        buffer.get(payload);

        Message message = new Message();
        message.headers = headers;
        message.payload = payload;
        return message;
    }

    private int calculateTotalLength(Message message) {
        int headerLength = message.headers.size() * (4 + 2 * MAX_HEADER_LENGTH); // 4 bytes for length, 2 for headers
        return 1 + headerLength + 4 + message.payload.length; // Header count + headers + payload length + payload
    }

    private void encodeString(ByteBuffer buffer, String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_HEADER_LENGTH) {
            throw new IllegalArgumentException("Header too long");
        }
        buffer.putShort((short) bytes.length);
        buffer.put(bytes);
    }

    private String decodeString(ByteBuffer buffer) {
        short length = buffer.getShort();
        if (length > MAX_HEADER_LENGTH) {
            throw new IllegalArgumentException("Header too long");
        }
        byte[] bytes = new byte[length];
        buffer.get(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
