package com.binarymessageencode.Service;

import java.util.Map;

public class Message {
    public Map<String, String> headers;
    public byte[] payload;

    public void setHeaders(Map<String, String> headers) {
    }

    public void setPayload(byte[] bytes) {
    }
}

