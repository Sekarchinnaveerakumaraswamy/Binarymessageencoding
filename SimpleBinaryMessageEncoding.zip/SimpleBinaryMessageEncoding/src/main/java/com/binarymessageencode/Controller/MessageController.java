package com.binarymessageencode.Controller;
import com.binarymessageencode.Service.Message;
import com.binarymessageencode.Service.MessageCodec;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/message")
//@security
public class MessageController {

    private final MessageCodec messageCodec;

    public MessageController(MessageCodec messageCodec) {
        this.messageCodec = messageCodec;
    }

    @PostMapping("/encode")
    public byte[] encodeMessage(@RequestBody Message message) {
        return messageCodec.encode(message);
    }

    @RequestMapping("/error")
    public String handleError() {
        // Your custom error handling logic
        return "errorPage"; // Return a view name for error page
    }

    @PostMapping("/decode")
    public Message decodeMessage(@RequestBody byte[] data) {
        return messageCodec.decode(data);
    }
}
