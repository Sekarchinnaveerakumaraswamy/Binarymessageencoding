package com.binarymessageencode;
import com.binarymessageencode.Service.MessageCode;
import com.binarymessageencode.Service.MessageCodec;
import org.slf4j.LoggerFactory;
//import org.slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Profile;

import javax.swing.plaf.basic.BasicSeparatorUI;
import java.util.logging.Logger;

@SpringBootApplication
@ComponentScan(basePackages = "com.binarymessageencode")
public class BinaryMessageEncodingApplication {

    //private static Logger applicationLogger= LoggerFactory.getLogger(BinaryMessageEncodingApplication.class);

    public static void main(String[] args) {

        SpringApplication.run(BinaryMessageEncodingApplication.class, args);
        System.out.println("Application Started");
    }

    @Bean
    @Profile("prod")
public String CreateProductionBean()
    {
       //applicationLogger.debug("Production Profile") ;
       return "prod";

    }


    @Bean
    public MessageCodec messageCodec() {
        // Instantiate and return your MessageCodec implementation
        return new MessageCode();
        }
        

}




